We are trying to Create a Search Engine Using PHP and MySql

This repository is part of a youtube tutorial series , if you are interested to learn how to development is done , you can go through this playlist.https://www.youtube.com/playlist?list=PLGmKMg3aRkXgqSBoqfer9FE4Phmi-KUFs

Both the tutorial series and this repository are currently work in progress, i will add new features and upload the video and commit the changes.
